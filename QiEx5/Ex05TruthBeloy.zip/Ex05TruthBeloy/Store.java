package ex05truthbeloy;

import java.util.*;

public class Store {
  private String name;
  private static double earnings;
  private ArrayList<Item> itemList;
  private static ArrayList<Store> storeList = new ArrayList();
  // private ArrayList<Item> filtered;
  
  public Store(String name){
      this.name = name;
      earnings = 0;
      itemList = new ArrayList<Item>();
      storeList.add(this);
// Initialize name to parameter and earnings to zero
    // Initialize itemList as a new ArrayList
    // add 'this' store to storeList
  }
  public String getName(){
    return name;
  }
  public double getEarnings(){
    return earnings;
  }
  public void sellItem(int index){
      if(index > itemList.size()) {
          System.out.println("There are only " + itemList.size() + " items in the store.\n");
          
      }
      else {
        earnings += itemList.get(index).getCost();
        System.out.println(itemList.get(index).getName() + " has been sold.\n");
      }
    // check if index is within the size of the itemList (if not, print statement that there are only x items in the store)
    // get Item at index from itemList and add its cost to earnings
    // print statement indicating the sale
  }
  public void sellItem(String name){
      boolean sellBool = false;
      for(Item i : itemList) {
          if(name == i.getName()) {
              earnings += i.getCost();
              System.out.println(name + " has been sold.\n");
              sellBool = true;
          }
      }
      if(sellBool == false) {
          System.out.println(name + " is not available in the store.\n");
      }
    // check if Item with given name is in the itemList (you will need to loop over itemList) (if not, print statement that the store doesn't sell it)
    // get Item from itemList and add its cost to earnings
    // print statement indicating the sale
  }
  public void sellItem(Item i){
      if(itemList.contains(i)) {
          earnings += i.getCost();
          System.out.println(i.getName() + " has been sold.\n");
      }
      else {
          System.out.println("This item is not available in the store.\n");
      }
    // check if Item i exists in the store (there is a method that can help with this) (if not, print statement that the store doesn't sell it)
    // get Item i from itemList and add its cost to earnings
    // print statement indicating the sale
  }
  public void addItem(Item i){
      itemList.add(i);
    
// add Item i to store's itemList
  }
  public void filterType(String type){
      // filtered.removeAll(itemList);
      System.out.println("Type: " + type);
      for(Item i : itemList) {
          if(type == i.getType()) {
              System.out.println(i.getName());
              //printAllItems();
          }
      }
      System.out.println("");
    // loop over itemList and print all items with the specified type
  }
  public void filterCheap(double maxCost){
      System.out.println("Items with a price cheaper than or equal to " + maxCost + ":");
      for(Item i : itemList) {
          if(i.getCost() <= maxCost) {
              System.out.println(i.getName());
          }
      }
      System.out.println("");
    // loop over itemList and print all items with a cost lower than or equal to the specified value
  }
  public void filterExpensive(double minCost){
      System.out.println("Items with a price more expensive than or equal to " + minCost + ":");
      for(Item i : itemList) {
          if(i.getCost() >= minCost) {
              System.out.println(i.getName());
          }
      }  
      System.out.println("");
// loop over itemList and print all items with a cost higher than or equal to the specified value
  }
  public String storeName() {
      return name;
  }
  public static void printStats(){
      System.out.println("List of stores:");
      for(Store i : storeList) {
          System.out.println(i.storeName());
      }
      System.out.println("\nTotal earnings: " + earnings);
  }
      
// loop over storeList and print the name and the earnings'Store.java'

}